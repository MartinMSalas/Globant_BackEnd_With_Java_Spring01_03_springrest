package com.martin.egg.springbootrest.service.impl;

import com.martin.egg.springbootrest.dto.ClientDTO;
import com.martin.egg.springbootrest.entity.Client;
import com.martin.egg.springbootrest.mapper.ClientMapper;
import com.martin.egg.springbootrest.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientService implements com.martin.egg.springbootrest.service.ClientService {

    private final ClientMapper clientMapper;
    private final ClientRepository clientRepository;

    @Autowired
    public ClientService(ClientMapper clientMapper, ClientRepository clientRepository) {
        this.clientMapper = clientMapper;
        this.clientRepository = clientRepository;
    }
    @Override
    public String getOneClient() {
        String client = "{'name':'Martin','surname':'Egg','age':25}"; //JSON
        return client;
    }

    @Override
    public ClientDTO createClient(ClientDTO clientDTO) {
        Client client = clientMapper.clientDTOToClient(clientDTO);
        clientDTO.setName("Dario");
        System.out.println(client);

        Client clientSaved = clientRepository.save(client);

        ClientDTO clientDTOSaved = clientMapper.clientToClientDTO(clientSaved);
        return clientDTOSaved;
    }

    @Override
    public void deleteClient(Long id) {
        clientRepository.deleteById(id);
    }


}

package com.martin.egg.springbootrest.service;

import com.martin.egg.springbootrest.dto.OrderDTO;

public interface OrderService {
    OrderDTO getOneOrder();
}
